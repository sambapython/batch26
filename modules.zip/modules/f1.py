def fun():
	return "this is fun in f1 modified"

	