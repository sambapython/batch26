print "this is file2"
def fun():
	return "this is fun in file2"

def main():
	print "some stetements to start"
	print fun()
	print "other statements ion p[ropgram"
if __name__ == "__main__":
	main()