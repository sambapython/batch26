from  inner_folder import file4
#print file4.fun()
print "this is file1"
def fun():
	return "this is fun in file1"

def main():
	print "some stetements to start"
	print fun()
	print "other statements ion p[ropgram"
if __name__ == "__main__":
	main()