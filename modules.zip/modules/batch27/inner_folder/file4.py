def fun():
	return "this is fun in inner_folder.fun4"